package fi.utu.tech.gui.javafx;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DummyTest {
    @Test
    public void dummy() throws Exception {
        assertTrue(true);
    }
}
