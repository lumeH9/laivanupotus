package fi.utu.tech.gui.javafx;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;

public class Ship extends ImageView {

    private int ship_id;
    private int height;
    private String name;
    private boolean dead = false;

    private double start_x;
    private double start_y;
    private double start_rotation;

    private double default_position_x = 20;
    private double default_position_y = 20;
    
    int shipHealth;
    
    private Board board;

    public Ship(int type, int ship_id, Board board) {

        String ship_name = "";
        int w = Board.cell_size;
        int h = 0;

        this.board = board;
        this.shipHealth = type;

        default_position_x = board.getGridEndingX() + 20;

        switch(type) {
            case 1:
                ship_name = "ship1.png";
                h = board.cell_size*2 + board.border;
                this.height = 2;
                name = "Hävittäjä";
                break;
            case 3:
                ship_name = "ship2.png";
                h = board.cell_size*3 + board.border*2;
                this.height = 3;
                name = "Risteilijä";
                break;
            case 2:
                ship_name = "ship3.png";
                h = board.cell_size*3 + board.border*2;
                this.height = 3;
                name = "Sukellusvene";
                break;
            case 4:
                ship_name = "ship4.png";
                h = board.cell_size*4 + board.border*3;
                this.height = 4;
                name = "Taistelulaiva";
                break;
            case 5:
                ship_name = "ship5.png";
                h = board.cell_size*5 + board.border*4;
                this.height = 5;
                name = "Lentotukialus";
                break;
        }

        Image image = new Image(getClass().getResourceAsStream(ship_name));
        setImage(image);

        setFitWidth(w);
        setFitHeight(h);

        setX(default_position_x);
        setY(default_position_y);

        this.ship_id = ship_id;

        //When clicked on the ship, it will start following mouse coordinates
        setOnMousePressed(e -> {
            if (board.getBoardIsPlacingShips() && e.getButton() == MouseButton.PRIMARY) {
                board.setImageOffsetX(e.getSceneX() - getX());
                board.setImageOffsetY(e.getSceneY() - getY());
                board.setPickedShip(this);

                start_x = getX();
                start_y = getY();
                start_rotation = getRotate();

                System.out.println("Ship ID: " + ship_id);

            }

        });
    }
    public void hit() {
        shipHealth--;
    }

    public boolean isAlive() {
        return shipHealth > 0;
    }

    public int getHeight() {
        return height;
    }

    public int getShipId() {
        return ship_id;
    }

    public double getStartX() {
        return start_x;
    }

    public double getStartY() {
        return start_y;
    }

    public double getStartRotation() {
        return start_rotation;
    }
    
    public boolean getDead() {
        return dead;
    }
    
    public void setDead(boolean b) {
        dead = b;
        if(dead) {
        	setVisible(true);
        	setOpacity(0.5);
        }
    }
    
    public String getName() {
    	return name;
    }

    public void resetPosition() {
        setX(default_position_x);
        setY(default_position_y);
        setRotate(0);
    }

}
