package fi.utu.tech.gui.javafx;

import java.util.ArrayList;

public class GameManager {

    private String pelaaja1;
    private String pelaaja2;
    private int korkeus;
    private int leveys;
    private ArrayList<Integer> laivojenLkm; //  !!-> indeksi 0=lentotuki 1=taistelu 2=risteilija 3=sukellusvene 4=havittaja



    public GameManager(String pelaaja1, String pelaaja2, int korkeus, int leveys) {
        this.pelaaja1 = pelaaja1;
        this.pelaaja2 = pelaaja2;
        this.korkeus = korkeus;
        this.leveys = leveys;


    }
    public int getlaivaSumma(){
        int summa = 0;
        for(int i =0; i<laivojenLkm.size();i++) {
            for (int k = 0; k < laivojenLkm.get(i); k++) {

                    switch (i) {
                        case 0:
                            summa = summa + 5;
                            break;
                        case 1:
                            summa = summa + 4;
                            break;
                        case 2:
                            summa = summa + 3;
                            break;
                        case 3:
                            summa = summa + 3;
                            break;
                        case 4:
                            summa = summa + 2;
                            break;
                    }
                }

        }
        System.out.println("Laivoilla lastattuja ruutuja: " + summa);
        return summa;
    }
    public String getPlayer1() {
        return this.pelaaja1;
    }

    public String getPlayer2() {
        return this.pelaaja2;
    }


    public int getHeight() {
        return this.korkeus;
    }

    public int getWidth() {
        return this.leveys;
    }
    // asetetaan sallittu lukumäärä per laivatyyppi -> indeksi 0=lentotuki 1=taistelu 2=risteilija 3=sukellusvene 4=havittaja

    public void setShipAmount(ArrayList<Integer> laivojenLkm) {
        System.out.println("Laivojen lukumäärät: " + laivojenLkm);
        this.laivojenLkm = laivojenLkm;
    }

    // getteri laivojen lukumäärille
    public ArrayList<Integer> getShipAmount() {
        return this.laivojenLkm;
    }


}




