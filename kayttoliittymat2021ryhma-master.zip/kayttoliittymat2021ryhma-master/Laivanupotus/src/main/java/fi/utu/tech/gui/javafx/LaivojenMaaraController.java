package fi.utu.tech.gui.javafx;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.NumberBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;

public class LaivojenMaaraController {

	Random craziness = new Random();
	GameManager u;
	IntegerProperty lentoNum = new SimpleIntegerProperty();
	IntegerProperty risteilijaNum = new SimpleIntegerProperty();
	IntegerProperty sukellusNum = new SimpleIntegerProperty();
	IntegerProperty havittajaNum = new SimpleIntegerProperty();
	IntegerProperty taisteluNum = new SimpleIntegerProperty();
	IntegerProperty vertikaaliNum = new SimpleIntegerProperty();
	IntegerProperty horisontaaliNum = new SimpleIntegerProperty();
	Color red = new Color(1, 0, 0, 0.6);
	NumberBinding laivaSumma;
	int laivaMax = 25;
	int vertikaali;
	int horisontaali;

	@FXML
	private BorderPane bPane;

	@FXML
	private Slider lento;

	@FXML
	private Slider risteilija;

	@FXML
	private Slider sukellus;

	@FXML
	private Slider havittaja;

	@FXML
	private Label lentoArvo;

	@FXML
	private Label taisteluArvo;

	@FXML
	private Label risteilijaArvo;

	@FXML
	private Label sukellusArvo;

	@FXML
	private Label havittajaArvo;

	@FXML
	private Slider taistelu;

	@FXML
	private Label virhe;

	@FXML
	private Button seuraava;

	@FXML
	private Button edellinen;

	@FXML
	private Label pelaaja1;

	@FXML
	private Label pelaaja2;

	@FXML
	void edellinenBtnPressed(ActionEvent event) {
		try {
			Parent newParent = FXMLLoader.load(getClass().getResource("NimetKoko.fxml"));
			Scene newScene = new Scene(newParent);

			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(newScene);
			stage.show();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	@FXML
	void seuraavaBtnPressed(ActionEvent event) {
		System.out.println("LaivaSumma: " + (int) laivaSumma.getValue());
		if ((int) laivaSumma.getValue() > laivaMax) {
			virhe.setText("*Vähennä laivojen määrää!");
			virhe.setTextFill(Color.RED);
		}
		else if((int)laivaSumma.getValue() == 0) {
			virhe.setText("*Aseta laivojen määrä!");
			virhe.setTextFill(Color.RED);
		}


		else {
			// tiedon välitys
			try {
				// puretaan bind
				lentoArvo.textProperty().unbind();
				risteilijaArvo.textProperty().unbind();
				sukellusArvo.textProperty().unbind();
				havittajaArvo.textProperty().unbind();
				taisteluArvo.textProperty().unbind();

				// asetetaan arvot ArrayListaan
				ArrayList<Integer> laivat = new ArrayList<>();
				laivat.add((int) Math.round(lento.getValue()));
				laivat.add((int) Math.round(taistelu.getValue()));
				laivat.add((int) Math.round(risteilija.getValue()));
				laivat.add((int) Math.round(sukellus.getValue()));
				laivat.add((int) Math.round(havittaja.getValue()));

				u.setShipAmount(laivat);

				try {
					Node node = (Node) event.getSource();
					Stage stage = (Stage) node.getScene().getWindow();

					Gameboard gb = new Gameboard(u, stage);


				} catch (Exception e) {
					e.printStackTrace();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	public void initialize() {
		// sidotaan sliderin arvot labeliin
		lentoArvo.textProperty().bind(Bindings.format("%.0f", lento.valueProperty()));
		risteilijaArvo.textProperty().bind(Bindings.format("%.0f", risteilija.valueProperty()));
		sukellusArvo.textProperty().bind(Bindings.format("%.0f", sukellus.valueProperty()));
		havittajaArvo.textProperty().bind(Bindings.format("%.0f", havittaja.valueProperty()));
		taisteluArvo.textProperty().bind(Bindings.format("%.0f", taistelu.valueProperty()));

		// sliderin arvot integeriksi
		lento.valueProperty().addListener((obs, oldval, newVal) -> lento.setValue(newVal.intValue()));
		risteilija.valueProperty().addListener((obs, oldval, newVal) -> risteilija.setValue(newVal.intValue()));
		sukellus.valueProperty().addListener((obs, oldval, newVal) -> sukellus.setValue(newVal.intValue()));
		havittaja.valueProperty().addListener((obs, oldval, newVal) -> havittaja.setValue(newVal.intValue()));
		taistelu.valueProperty().addListener((obs, oldval, newVal) -> taistelu.setValue(newVal.intValue()));
	}

	public void setData(GameManager data) {
		this.u = data;
		this.vertikaali = u.getHeight();
		this.horisontaali = u.getWidth();
		System.out.println("vertikaali: " + vertikaali + " horisontaali: " + horisontaali);
		this.laivaMax = vertikaali * horisontaali / 2;
		System.out.println("laivaMax: " + laivaMax);
		pelaaja1.setText(u.getPlayer1());
		pelaaja2.setText(u.getPlayer2());

		// sidotaan sliderin arvot SimpleIntegerPropertyyn
		lento.valueProperty().bindBidirectional(lentoNum);
		risteilija.valueProperty().bindBidirectional(risteilijaNum);
		sukellus.valueProperty().bindBidirectional(sukellusNum);
		havittaja.valueProperty().bindBidirectional(havittajaNum);
		taistelu.valueProperty().bindBidirectional(taisteluNum);
		laivaSumma = (lentoNum.multiply(5)).add((risteilijaNum).multiply(3)).add((sukellusNum).multiply(3))
				.add((havittajaNum).multiply(2)).add((taisteluNum).multiply(4)); // laivojen yhteismäärä

		// tekstin värin vaihtuminen
		lentoArvo.textFillProperty()
				.bind(Bindings.when(laivaSumma.lessThanOrEqualTo(laivaMax)).then(Color.GREEN).otherwise(red));
		risteilijaArvo.textFillProperty()
				.bind(Bindings.when(laivaSumma.lessThanOrEqualTo(laivaMax)).then(Color.GREEN).otherwise(red));
		sukellusArvo.textFillProperty()
				.bind(Bindings.when(laivaSumma.lessThanOrEqualTo(laivaMax)).then(Color.GREEN).otherwise(red));
		havittajaArvo.textFillProperty()
				.bind(Bindings.when(laivaSumma.lessThanOrEqualTo(laivaMax)).then(Color.GREEN).otherwise(red));
		taisteluArvo.textFillProperty()
				.bind(Bindings.when(laivaSumma.lessThanOrEqualTo(laivaMax)).then(Color.GREEN).otherwise(red));

	}
}
