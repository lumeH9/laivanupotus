package fi.utu.tech.gui.javafx;

public class Main {

    public static void main(String[] args) {
		MainApp.launch(MainApp.class, args);
    }
}

