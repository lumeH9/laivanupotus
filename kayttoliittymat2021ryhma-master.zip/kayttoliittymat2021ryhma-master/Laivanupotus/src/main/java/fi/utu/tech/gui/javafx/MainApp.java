package fi.utu.tech.gui.javafx;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


public class MainApp extends Application{
	Stage stage;
    //private ImageBlackBox imageBlackBox = new ImageBlackBox();
    String sisalto;
   
	public void start(Stage stage) { //Throws exception
	    this.stage = stage; 
        stage.setTitle("Laivanupotuspeli");
        
        //Luodaan Paneelit
        BorderPane bPane = new BorderPane(); 
        bPane.setId("pane");
        
        //Luodaan objektit
        Button aloitus = new Button();
        aloitus.setId("start");
        aloitus.setText("Aloita");
       
        //Määritetään Scenen koko ja asetetaan sisältö
        Scene scene = new Scene(bPane, 500, 460); 
        scene.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());//scenen tyyli
        bPane.setCenter(aloitus);
        
        
        //Asetetaan Stagen sisältö
        stage.setScene(scene); //Scene stagen sisään
        stage.show(); // Stage näkyväksi
        System.out.println("Aloitus scene");
        
        //toiminnallisuus avaa seuraavan scenen
        aloitus.setOnMouseClicked(e -> {
        	var loader = new FXMLLoader(getClass().getResource("NimetKoko.fxml"));

            // Load and parse the FXML into an Java object (Parent)
            Parent root;
			try {
				root = loader.load();
				// This is just the usual: Setting scene, showing stage
	            var scene2 = new Scene(root);
	            stage.setScene(scene2);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            
            stage.show();
        	
        });
        
       }
		
  
}


