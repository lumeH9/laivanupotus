package fi.utu.tech.gui.javafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;

public class NimetKokoController {
	String pelaaja1M;
	String pelaaja2M;
	int vertikaaliM;
	int horisontaaliM;
	
	
    @FXML
    private BorderPane bPane;

    @FXML
    private TextField pelaaja2text;

    @FXML
    private Slider vertikaali;

    @FXML
    private Slider horisontaali;

    @FXML
    private Label horisontaaliArvo;

    @FXML
    private Label vertikaaliArvo;

    @FXML
    private TextField pelaaja1text;
    
    @FXML
    private Label virhe;

    @FXML
    private Button seuraava;

    @FXML
    private Label pelaaja1;

    @FXML
    private Label pelaaja2;

    @FXML
    void seuraavaBtnPressed(ActionEvent event) {
    	if(pelaaja1.getText().equals("") || pelaaja2.getText().equals("")) {
    		virhe.setText("*Pelaajatietoja puuttuu!");
    		virhe.setTextFill(Color.RED);
    	}
    	else {
    	//tiedon välitys
    	try {
    		  pelaaja1.textProperty().unbind();
    		  pelaaja2.textProperty().unbind();
    		  vertikaaliArvo.textProperty().unbind();
              horisontaaliArvo.textProperty().unbind();
              pelaaja1M = pelaaja1.getText();
              pelaaja2M = pelaaja2.getText();
              System.out.println("pelaaja1: " + pelaaja1M + " pelaaja2: " + pelaaja2M);
              horisontaaliM = (int) Math.round(horisontaali.getValue());
              vertikaaliM = (int) Math.round(vertikaali.getValue());
              System.out.println("horisontaali: " + horisontaaliM + " vertikaali: " + vertikaaliM);
              
    		  GameManager u = new GameManager(pelaaja1M, pelaaja2M, horisontaaliM, vertikaaliM);
    		  Node node = (Node) event.getSource();
    		  Stage stage = (Stage) node.getScene().getWindow();
    		 
    		  try {
    			FXMLLoader loader = new FXMLLoader(getClass().getResource("LaivojenMaara.fxml"));
    			Parent root = loader.load();
    		   
    		    LaivojenMaaraController controller = loader.getController();
    		    controller.setData(u);
    		    loader.setController(controller);
    		
    		    Scene scene = new Scene(root);
    		    stage.setScene(scene);
    		    stage.show();
    		  }catch(Exception e) {
    			  e.printStackTrace();
    		  }
    		} catch (Exception e1) {
    			e1.printStackTrace();
    		}
    	}
    		
    }
    
    public void initialize() {
        pelaaja1.textProperty().bind(pelaaja1text.textProperty());
        pelaaja2.textProperty().bind(pelaaja2text.textProperty());
        vertikaaliArvo.textProperty().bind(Bindings.format("%.0f", vertikaali.valueProperty()));
        horisontaaliArvo.textProperty().bind(Bindings.format("%.0f", horisontaali.valueProperty()));
   }
   
}


