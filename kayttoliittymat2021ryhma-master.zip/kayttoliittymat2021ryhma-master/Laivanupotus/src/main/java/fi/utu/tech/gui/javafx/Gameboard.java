package fi.utu.tech.gui.javafx;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class Gameboard {

    public  Scene scene;
    public Group root;
    public static Scene changePlayerScene;
    public static Scene changePlayerScene1;
    public static Scene youWonScene;

    int pelaajan1Vuoro = 1;
    boolean pelaaja2Ampuu = false;
    static boolean ampuminenOnAlkanut = false;
    
    public static Label pelaaja_teksti = new Label();
    public static Label voitit = new Label("V O I T I T PELIN !!!");

    Board board2;
    Board board;
    
    private boolean ships_placed = false;


    //@Override
    public Gameboard(GameManager u, Stage stage) {
        super();

        board2 = new Board(500, 50, u, stage, u.getPlayer2(), 2);
        board = new Board(1, 50, u, stage, u.getPlayer1(), 1);

        pelaaja_teksti.setText("Pelaajan "+u.getPlayer1()+" vuoro asettaa laivansa. Aseta laivat ruudukkoon\nvetämällä laivaa hiiren vasen nappi pohjassa. Laivaa voi kääntää R-näppäimestä.\nPaina \"Lopeta vuoro\", kun olet asettanut laivasi.");
        pelaaja_teksti.setLayoutX(200);
        board.getRoot().setDisable(false);
        board2.getRoot().setDisable(true);

		Button button = new Button("Lopeta vuoro");

		button.setOnAction(e -> {
			//Checks if all ships have been placed to the board
            board.all_ships_placed = true;    
            board2.all_ships_placed = true;
            boolean error = false;
            
            if (!ships_placed) {
	            if(pelaajan1Vuoro == 1) {
	            	if(board.ship_list.size() != board.placedShips.size())
	            		error = true;
	
	            	if(error) {
	                	board.all_ships_placed = false;
	                	board.error_label.setText(board.error_ship_missing);
	                }
	            	//All ships placed
	            	else {
	                    board.canReset = false;
	                    board.hideShips(false);
	                    board.getHBox().getChildren().remove(board.getButton());
	                    pelaajan1Vuoro *= -1;
	                    
	                    pelaaja_teksti.setText("Pelaajan "+u.getPlayer2()+" vuoro asettaa laivansa. Aseta laivat ruudukkoon\nvetämällä laivaa hiiren vasen nappi pohjassa. Laivaa voi kääntää R-näppäimestä.\nPaina \"Lopeta vuoro\", kun olet asettanut laivasi.");
						board.getRoot().setDisable(true);
						board2.getRoot().setDisable(false);
						board.board_place_ships = false;
						
						stage.setScene(changePlayerScene1);
	                }
	            }
	            else {
	            	if(board2.ship_list.size() != board2.placedShips.size())
	            		error = true;
	            	
	            	if(error) {
	                	board2.all_ships_placed = false;
	                	board2.error_label.setText(board2.error_ship_missing);
	                }
	            	//All ships placed
	            	else {
	                    board2.canReset = false;
	                    board2.hideShips(false);
	                    board2.getHBox().getChildren().remove(board2.getButton());
	                    
	                    pelaaja_teksti.setText("Pelaajan "+u.getPlayer1()+" vuoro ampua. Vihollisesta on tuhottu: "
								+ Math.round( ((double) board.playerPoints / u.getlaivaSumma()) * 100 ) + " %");
						board.getRoot().setDisable(true);
						board2.getRoot().setDisable(false);
						board2.board_place_ships = false;
						
						stage.setScene(changePlayerScene);
						board.error_label.setText("");
						
						board.hideShips(true);
						board.setHasShots(true);
						ships_placed = true;
						pelaajan1Vuoro *= -1;
	                }
	            }
            }
            

            else if ((pelaajan1Vuoro == 1  && !board2.getHasShots()) || (pelaajan1Vuoro == -1 && !board.getHasShots())) {

				pelaajan1Vuoro *= -1;

				if (pelaajan1Vuoro > 0) {
					board.hideShips(true);
					board2.hideShips(false);
					stage.setScene(changePlayerScene);

					board2.setHasShots(true); // laudalle voi jälleen ampua hudin, eli veteen ampumisen jälkeen
					board.error_label.setText(""); // poistetaan edellisen vuoron errorit

					pelaaja_teksti.setText("Pelaajan "+u.getPlayer1()+" vuoro ampua. Vihollisesta on tuhottu: "
							+ Math.round( ((double) board.playerPoints / u.getlaivaSumma()) * 100 ) + " %");
					
					board.getRoot().setDisable(true); // estetään vuorovaikutus yhden laudan kanssa ja sallitaan toisen
					board2.getRoot().setDisable(false);

				} else {
					board.hideShips(false);
					board2.hideShips(true);
					stage.setScene(changePlayerScene1);
					board2.error_label.setText("");

					pelaaja_teksti.setText("Pelaajan "+u.getPlayer2()+" vuoro ampua. Vihollisesta on tuhottu: "
							+ Math.round( ((double) board2.playerPoints / u.getlaivaSumma()) * 100 ) + " %");
					board.getRoot().setDisable(false);
					board2.getRoot().setDisable(true);
					board.setHasShots(true);
				}
			}
			else {
				System.out.println("aseta kaikki laivasi ennen vuorosi loppua!");
			}
		});


        Group root = new Group(board.getRoot(), board2.getRoot(), button, pelaaja_teksti);
        Scene scene = new Scene(root, 1000, 600);
        Label label = new Label("Aloita vuorosi "+u.getPlayer1());
        Label label2 = new Label("Aloita vuorosi "+u.getPlayer2());

        Button button2 = new Button("OK");
        Button button3 = new Button("OK");
        VBox vbox1 = new VBox(label, button2);
        VBox vbox2 = new VBox(label2, button3);
        vbox1.setAlignment(Pos.CENTER);
        vbox1.setSpacing(20);
        vbox2.setAlignment(Pos.CENTER);
        vbox2.setSpacing(20);
        BorderPane root2 = new BorderPane();
        BorderPane root4 = new BorderPane();

        root2.setCenter(vbox1);
        root4.setCenter(vbox2);

        voitit = new Label("V O I T I T PELIN !!!");
        voitit.setTextFill(Color.GREEN);
        voitit.setLayoutX(200);
        Button uudestaan = new Button("Aloita peli uudestaan eri asetuksilla");
        Button uudestaan2 = new Button("Aloita peli uudestaan samoilla asetuksilla");
        voitit.setLayoutX(400);
        voitit.setLayoutY(200);
        uudestaan2.setLayoutX(500);
        uudestaan2.setLayoutX(500);
        Group root3 = new Group(voitit, uudestaan, uudestaan2);
        
        button2.setOnAction(e -> {

            stage.setScene(scene);
        });
        button3.setOnAction(e -> {

            stage.setScene(scene);
        });
		// pelin restart uusilla asetuksilla
		uudestaan.setOnAction(e -> {

			Parent newParent;
			try {
				newParent = FXMLLoader.load(getClass().getResource("NimetKoko.fxml"));
				Scene newScene = new Scene(newParent);

				Stage stage2 = (Stage) ((Node) e.getSource()).getScene().getWindow();
				stage2.setScene(newScene);
				stage2.show();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		});

		// pelin restart samoilla asetuksilla
		uudestaan2.setOnAction(e -> {
			Gameboard gb = new Gameboard(u, stage);
		});

        changePlayerScene = new Scene(root2, 1000, 600);
        changePlayerScene1 = new Scene(root4, 1000, 600);

        youWonScene = new Scene(root3, 1000,600);

        stage.setScene(scene);
    }


    public void resetCoord(Board board) {
        for (int i = 0; i < board.ship_list.size(); i++) {
            if (board.ship_list.get(i) != null){
                System.out.println("resetoiko");
                board.ship_list.get(i).resetPosition();
            }
        }
    }

    public Group getGroup(){
        return root;

    }
    public Scene getScene() {
        return scene;
    }
}


