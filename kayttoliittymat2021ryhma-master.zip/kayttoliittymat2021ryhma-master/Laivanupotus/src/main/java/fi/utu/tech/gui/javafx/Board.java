package fi.utu.tech.gui.javafx;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Board {

    BorderPane root = new BorderPane();
    
    
    int [][] gameboard;
    public ArrayList<Ship>  ship_list;
    ArrayList<Integer> placedShips;
    public int ship_amount;
    public GameManager u;

    //These values can be changed to customise the gameboard size and position
    private int board_starting_x;
    private int board_starting_y;
    public static int cell_size = 32;
    int board_sizey ;
    int board_sizex ;
    public static int border = 1;

    //Controls when the board can be clicked
    public boolean board_place_ships = true;
    private boolean board_is_turn = true;
    private boolean shotsLeft = true;

    private final String error_outside_of_grid = "Laiva ei voi olla ruudukon ulkopuolella!";
    private final String error_ship_collision = "Laiva ei voi olla toisen laivan päällä!";
    final String error_ship_missing = "Kaikkia laivoja ei ole sijoitettu ruudukkoon!";
    private final String error_noShotsLeft = "Osuit veteen, joten et voi ampua tämän" + "\n" + "vuoron aikana enää!";
    public Label error_label = new Label("");

    //These values store the dragged ship and its coordinates
    private double image_offset_x;
    private double image_offset_y;
    private Ship picked_ship;
    private double mouse_x;
    private double mouse_y;

    private int ship_grid_x = -1;
    private int ship_grid_y = -1;

    private int grid_ending_x;
    private int grid_ending_y;

    public boolean free;
    public boolean canReset = true;
    boolean all_ships_placed; // = true

    public int playerPoints = 0;

    public Stage stage;
    
    private String player_name;
    private int player_num;
    
    private Button b2;
    private HBox hbox;
    
    private ArrayList<ImageView> list_explosion = new ArrayList<>();
    private ArrayList<Integer> list_explosion_id = new ArrayList<>();

    public Board(int board_x, int board_y, GameManager u, Stage stage, String p_name, int p_num) {
        this.stage = stage;
        this.u = u;
        
        player_name = p_name;
        player_num = p_num;
        
        error_label.setTextFill(Color.RED);

        placedShips = new ArrayList<Integer>();
        
        board_starting_x = 1;
        board_starting_y = 50;
        
        System.out.println("board vertikaali: " + u.getWidth() + " horisontaali: " + u.getHeight());
        this.board_sizey = u.getWidth();
        this.board_sizex = u.getHeight();

        root.setLayoutX(board_x);
        root.setLayoutY(board_y);
        
        //Calculating where the gameboard ends, so that we know the boundaries
        grid_ending_x = board_starting_x + cell_size * board_sizex + board_sizex*border;
        grid_ending_y = board_starting_y + cell_size * board_sizey + board_sizey*border;
        
        System.out.print(board_is_turn);
        
        //Creating the gameboard
        gameboard = new int[board_sizex][board_sizey];

        //Draw outlines for gameboard
        int outline_x = board_starting_x-1;
        int outline_y = board_starting_y-1;
        int outline_x2 = grid_ending_x - board_starting_x + 1;
        int outline_y2 = grid_ending_y - board_starting_y + 1;
        paintGridBase(outline_x, outline_y, outline_x2, outline_y2, Color.BLACK);

        //Drawing the empty gameboard
        for(int i=0; i < board_sizex; i++) {
            for(int j=0; j < board_sizey; j++) {
                //Drawing gameboard
                int x = getScreenXFromGameboardX(i); // i j
                int y = getScreenYFromGameboardY(j);
            	
                Color color;
                color = Color.PALETURQUOISE;

                paintGrid(x, y, color);
            }
        }
        
        //Creating the ships
        ship_amount = 0;
        int idapu = 1;
        ship_list = new ArrayList<Ship>();

        for(int g=0; g<u.getShipAmount().size(); g++){

            if(u.getShipAmount().get(g) >0 && u.getShipAmount().get(g) != null){

                for(int f=0; f<u.getShipAmount().get(g); f++){
                	ship_list.add(createShip(5-g, idapu));
                	
                    System.out.println("type: " + (5-g) + "ship id: " + idapu);
                    ship_amount ++;
                    idapu++;
                }
            }
        }

        b2 = new Button("Reset");
        b2.setOnAction(e -> {
            if (canReset) {
                //Resets coordinates for ships that are on the board
                for (int i = 0; i < ship_list.size(); i++) {
                    if (ship_list.get(i) != null) {
                        ship_list.get(i).resetPosition();
                    }
                }
                placedShips.clear();
                
                //Also resets all values in gameboard[][]
                for (int i = 0; i < board_sizex; i++) {
                    for (int j = 0; j < board_sizey; j++) {
                        gameboard[i][j] = 0;
                    }
                }
                
            }
        });
        
        hbox = new HBox(b2, error_label);
        Label pelaajan_lauta = new Label("Pelaajan "+player_name+" lauta");
        VBox vbox = new VBox(hbox, pelaajan_lauta);
        
		root.setTop(vbox);

        //Makes that the ship will move where your mouse is
        root.setOnMouseDragged(e -> {
            if (board_is_turn && picked_ship != null) {

                if (picked_ship.getRotate() != 0 && picked_ship.getHeight()%2 == 0) {
                	
                    ship_grid_x = (int) Math.floor((e.getSceneX() - board_starting_x - image_offset_x + cell_size / 2) / (cell_size + border));
                    ship_grid_y = (int) Math.floor((e.getSceneY() - board_starting_y - image_offset_y + cell_size / 2) / (cell_size + border));
                } else {
                    ship_grid_x = (int) Math.floor((e.getSceneX() - board_starting_x - image_offset_x + cell_size / 2) / (cell_size + border));
                    ship_grid_y = (int) Math.floor((e.getSceneY() - board_starting_y - image_offset_y + cell_size / 2) / (cell_size + border));
                }
                
                int x = getScreenXFromGameboardX(ship_grid_x);
                int y = getScreenYFromGameboardY(ship_grid_y);

                mouse_x = e.getSceneX();
                mouse_y = e.getSceneY();
                
                picked_ship.setX(x);
                picked_ship.setY(y);

                if (picked_ship.getRotate() != 0 && picked_ship.getHeight()%2 == 0) {
                    picked_ship.setX((int) Math.floor(picked_ship.getX() - cell_size/2));
                    picked_ship.setY((int) Math.floor(picked_ship.getY() + cell_size/2));
                }
            }
            
          //Rotate ship when R is pressed
          root.getScene().setOnKeyPressed(e2 -> {
                if (e2.getCode() == KeyCode.R) {
                    if (board_is_turn && picked_ship != null) {

                        if(picked_ship.getRotate() == 0) {
                            picked_ship.setRotate(-90);
                        }
                        else {
                            picked_ship.setRotate(0);
                        }

                        int grid_x = (int) Math.floor((mouse_x - board_starting_x - image_offset_x + cell_size/2) / (cell_size + border));
                        int grid_y = (int) Math.floor((mouse_y - board_starting_y - image_offset_y + cell_size/2) / (cell_size + border));

                        int x = getScreenXFromGameboardX(grid_x);
                        int y = getScreenYFromGameboardY(grid_y);

                        picked_ship.setX(x);
                        picked_ship.setY(y);

                        if (picked_ship.getRotate() != 0 && picked_ship.getHeight()%2 == 0) {
                            picked_ship.setX((int) Math.floor(picked_ship.getX() - cell_size/2));
                            picked_ship.setY((int) Math.floor(picked_ship.getY() + cell_size/2));
                        }

                    }
                }
            });
            
        });

        //Mouse clicked, Left click -> shoot
        root.setOnMouseClicked(e -> {

            if (!board_place_ships && board_is_turn && e.getButton() == MouseButton.PRIMARY){
                //Check if cursor is on the gameboard, otherwise nothing happens
                if(e.getX() >= board_starting_x && e.getX() <= grid_ending_x &&
                        e.getY() >= board_starting_y && e.getY() <= grid_ending_y) {
                    //Calculate grid cell number from cursor position
                    int grid_x = getGameboardXFromScreenX(e.getX());
                    int grid_y = getGameboardYFromScreenY(e.getY());

                    try {
                        shootGrid(grid_x, grid_y);
                    } catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                }
            }
        });

        //When mouse button is not pressed anymore, stop moving the ship
        root.setOnMouseReleased(e -> {
            if (board_is_turn && e.getButton() == MouseButton.PRIMARY && picked_ship != null) {
            	
                ship_grid_x = (int) Math.floor((e.getSceneX() - board_starting_x - image_offset_x + cell_size/2) / (cell_size + border));
                ship_grid_y = (int) Math.floor((e.getSceneY() - board_starting_y - image_offset_y + cell_size/2) / (cell_size + border));

                free = true;

                //Collision checks, different for horizontal and vertical ships
                if (picked_ship.getRotate()%180 != 0) {
                    int new_x = (int) Math.floor(ship_grid_x-Math.floor(picked_ship.getHeight()/2));
                    int new_y = (int) Math.floor(ship_grid_y+Math.floor(picked_ship.getHeight()/2));

                    System.out.println("SIDE All positions: ");

                    checkPositionsAreFree(new_x, new_y, false);

                    //save ship positions to gameboard
					if (free) {

						// No errors
						error_label.setText("");

						// remove previous ship positions from gameboard
						removeShips();

						// put new positions to gameboard
						for (int i = 0; i < picked_ship.getHeight(); i++) {
							System.out.print("[" + (new_x + i) + ", " + (new_y) + "]");
							gameboard[new_x + i][new_y] = picked_ship.getShipId();
							
							if (!placedShips.contains(picked_ship.getShipId())) {
								placedShips.add(picked_ship.getShipId());
							}
						}
					}
					// cell is occupied, go back to previous position
					else {
						picked_ship.setRotate(picked_ship.getStartRotation());
						picked_ship.setX(picked_ship.getStartX());
						picked_ship.setY(picked_ship.getStartY());
					}
				} else {
					System.out.println("UP All positions: ");

					checkPositionsAreFree(ship_grid_x, ship_grid_y, true);

					// save ship positions to gameboard
					if (free) {

						// No errors
						error_label.setText("");

						// remove previous ship positions from gameboard
						removeShips();

						// put new positions to gameboard
						for (int i = 0; i < picked_ship.getHeight(); i++) {
							System.out.print("[" + (ship_grid_x) + ", " + (ship_grid_y + i) + "]");
							// save ship positions to gameboard
							gameboard[ship_grid_x][ship_grid_y + i] = picked_ship.getShipId();
							//gameboard[ship_grid_x + i][ship_grid_y] = picked_ship.getShipId();
							
							if (!placedShips.contains(picked_ship.getShipId())) {
								placedShips.add(picked_ship.getShipId());
							}
						}
					}
					// cell is occupied, go back to previous position
					else {
						picked_ship.setRotate(picked_ship.getStartRotation());
						picked_ship.setX(picked_ship.getStartX());
						picked_ship.setY(picked_ship.getStartY());
					}
				}
                picked_ship = null;
            }
        });
    }

    public void checkPositionsAreFree(int x, int y, boolean vertical) {

        int num;

        for (int i = 0; i < picked_ship.getHeight(); i++) {

            if (vertical) {
                // If outside of bounds
                  if (ship_grid_x < 0 || ship_grid_x >= gameboard.length || ship_grid_y+i < 0 || ship_grid_y+i >= gameboard[0].length) {
                    free = false;
                    error_label.setText(error_outside_of_grid);
                    break;
                }
                num = gameboard[ship_grid_x][ship_grid_y+i];

            } else {
            	 //If outside of bounds
                if (x+i < 0 || x+i >= gameboard.length || y < 0 || y >= gameboard[0].length) {
                    free = false;
                    error_label.setText(error_outside_of_grid);
                    break;
                }
                num = gameboard[x+i][y];
            }
            // If another ship is in the place
            if (num != 0 && num != picked_ship.getShipId()) {
                free = false;
                error_label.setText(error_ship_collision);
                break;
            }
        }
    }
       public void removeShips() {
        for(int i=0; i< u.getHeight(); i++) {
            for(int j=0; j<u.getWidth(); j++) {
                if(gameboard[i][j] == picked_ship.getShipId()) {
                    gameboard[i][j] = 0;
                }
            }
        }
    }

    //Draw the base for grid (outlines)
    public void paintGridBase(int x, int y, int x2, int y2, Color color) {
        System.out.println("piirtääkö");
        Rectangle cell = new Rectangle();
        cell.setX(x);
        cell.setY(y);
        cell.setWidth(x2);
        cell.setHeight(y2);

        cell.setFill(color);

        root.getChildren().add(cell);
    }

    //Draw rectangle at certain coordinates (Used for making water)
    public void paintGrid(int x, int y, Color color) {

        Rectangle cell = new Rectangle();
        cell.setX(x);
        cell.setY(y);
        cell.setWidth(cell_size);
        cell.setHeight(cell_size);

        cell.setFill(color);

        root.getChildren().add(cell);
    }

    //Player shoots at a cell
    public void shootGrid(int x, int y) throws InterruptedException {

        //You have finished placing your ships, must be your turn and you haven't hit water
        if(!board_place_ships && board_is_turn && shotsLeft) {

            String image_name = "";
            int ship_id = 0;
            boolean place_explosion = true;

            //Check whether player hits water or ship
            if (gameboard[x][y] == 0) {
                image_name = "bomb.png";
                System.out.println("player points " + playerPoints);
                error_label.setText(error_noShotsLeft);
                error_label.setTextFill(Color.BLUE);
                shotsLeft = false;
                gameboard[x][y] = -1;

			} else if (gameboard[x][y] > 0) {
				//Hits a ship
				ship_id = gameboard[x][y];
				System.out.println("ID: "+ship_id);
				
				image_name = "explosion.png";
				error_label.setText("Osuit vihollisen laivaan! Ammu uudelleen.");
				error_label.setTextFill(Color.GREEN);
				playerPoints++;
				
				String current_player_name;
				
				if (player_num == 1)
					current_player_name = u.getPlayer2();
				else current_player_name = u.getPlayer1();
				
				Gameboard.pelaaja_teksti.setText("Pelaajan "+current_player_name+" vuoro ampua. Vihollisesta on tuhottu: "
						+ Math.round( ((double) playerPoints / u.getlaivaSumma()) * 100 ) + " %");
				
				//Delete from board
				gameboard[x][y] = -1;
				
				//Check if the ship is still alive
				boolean ship_alive = false;
				for(int j=0; j < gameboard[0].length; j++) {
					for(int i=0; i < gameboard.length; i++) {
						if (gameboard[i][j] == ship_id) {
							System.out.println("laiva olemassa");
							ship_alive = true;
							break;
						}
					}
				}
				
				if (!ship_alive) {
					
					image_name = "splash3.png";
					place_explosion = false;
					
					for(int i=0; i < ship_list.size(); i++) {
						Ship current_ship = ship_list.get(i);
						if (current_ship.getShipId() == ship_id) {
							current_ship.setDead(true);
							error_label.setText("Upotit vihollisen laivan "+current_ship.getName()+"! Ammu uudelleen.");
							error_label.setTextFill(Color.RED);
							for(int j=0; j < list_explosion.size(); j++) {
								if(list_explosion_id.get(j) == ship_id) {
									list_explosion.get(j).setImage(new Image(getClass().getResourceAsStream(image_name)));
									list_explosion.remove(j);
									list_explosion_id.remove(j);
									j--;
								}
							}
							break;
						}
					}
				}
				
				if (playerPoints == u.getlaivaSumma()) {
					Gameboard.voitit.setText(current_player_name+", V O I T I T PELIN !!!");
					Gameboard.voitit.setTextFill(Color.GREEN);
					stage.setScene(Gameboard.youWonScene);
					return;
				}
			}
			else return;
			
            Image image = new Image(getClass().getResourceAsStream(image_name));
            ImageView imageView = new ImageView(image);

            //Get the grid cell's x and y screen coordinates
            int grid_x = getScreenXFromGameboardX(x);
            int grid_y = getScreenYFromGameboardY(y);
            
            imageView.setX(grid_x);
            imageView.setY(grid_y);
            imageView.setFitWidth(cell_size);
            imageView.setFitHeight(cell_size);
            
            if (ship_id > 0 && place_explosion) {
	            list_explosion.add(imageView);
	            list_explosion_id.add(ship_id);
            }

            root.getChildren().add(imageView);
        }
    }


    //Returns the board
    public BorderPane getRoot() {
        return root;
    }

    //Converts screen position to gameboard[][] x position
    public int getGameboardXFromScreenX(double mouse_x) {
        return (int) Math.floor((mouse_x - board_starting_x) / (cell_size + border));
    }

    //Converts screen position to gameboard[][] y position
    public int getGameboardYFromScreenY(double mouse_y) {
        return (int) Math.floor((mouse_y - board_starting_y) / (cell_size + border));
    }

    //Converts gameboard[][] x position to screen x position
    public int getScreenXFromGameboardX(int number) {
        return board_starting_x + number * cell_size + number*border;
    }

    //Converts gameboard[][] y position to screen y position
    public int getScreenYFromGameboardY(int number) {
        return board_starting_y + number * cell_size + number*border;
    }

    public void setImageOffsetX(double x) {
        image_offset_x = x;
    }
    public void setImageOffsetY(double y) {
        image_offset_y = y;
    }
    public void setPickedShip(Ship ship) {
        picked_ship = ship;
    }

    public int getGridEndingX() {
        return grid_ending_x;
    }

    public boolean getBoardIsPlacingShips() {
        return board_place_ships;
    }
    
    public HBox getHBox() {
    	return hbox;
    }
    
    public Button getButton() {
    	return b2;
    }
    
    public boolean getHasShots() {
    	return shotsLeft;
    }
    
    public void setHasShots(boolean b) {
    	shotsLeft = b;
    }
    

    public void addToShipList(Ship ship) {
        ship_list.add(ship);
        System.out.println("laivalistaan lisätty" + ship.getShipId());
    }
    public void hideShips(boolean b) {
        //Hide ship images that are on the board
        for (int i = 0; i < ship_amount; i++) {
            if (ship_list.get(i) != null && !ship_list.get(i).getDead())
                ship_list.get(i).setVisible(b);
        }
    }

    public Ship createShip(int type, int ship_id) {
        Ship ship = new Ship(type, ship_id, this);
        root.getChildren().add(ship);
        return ship;
    }

}