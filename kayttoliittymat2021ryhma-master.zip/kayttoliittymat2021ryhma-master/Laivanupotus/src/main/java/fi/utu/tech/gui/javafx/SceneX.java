package fi.utu.tech.gui.javafx;



import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SceneX {
	
    Scene sceneX;
    Gameboard gb ;
	
	public SceneX(GameManager u) {
		super();

		//luodaan Panet
		BorderPane bPane2 = new BorderPane(); 
		GridPane layoutYla = new GridPane();
	    GridPane layoutAla = new GridPane();
	    sceneX = new Scene(bPane2, 500, 460); //uusi scene
		
		//Luodaan objektit
		Label pelaaja1 = new Label(u.getPlayer1());
		Label pelaaja2 = new Label(u.getPlayer2());
	    Button seuraava = new Button();
	    Button edellinen = new Button();

	    edellinen.setText("< Edellinen");
	    seuraava.setText("Seuraava >");
	   
	    //Määritetään Scenen koko ja asetetaan sisältö
	    bPane2.setTop(layoutYla); //Gridpanet borderpanen sisään
	    bPane2.setBottom(layoutAla); 
	    bPane2.setCenter(gb.getGroup());
	   
	    //YläLayout
	    layoutYla.setHgap(120);  //spacing gridien välillä
	    layoutYla.setGridLinesVisible(false);
	    layoutYla.setAlignment(Pos.CENTER); ; //keskitys
	    layoutYla.setPadding(new Insets(8, 8, 8, 8)); //marginaali ylä- ja alapuolella
	    pelaaja1.setAlignment(Pos.CENTER);
	    
	    layoutYla.add(pelaaja1, 0, 0); 
        layoutYla.add(pelaaja2, 1, 0); 
	    
	    //AlaLayoutin gridi-asettelua 
	    layoutAla.setHgap(10);  //spacing gridien välillä
	    layoutAla.setGridLinesVisible(false);
	    layoutAla.setAlignment(Pos.CENTER); //keskitys
	    layoutAla.setPadding(new Insets(8, 8, 8, 8)); //marginaali ylä- ja alapuolella
	    
	    layoutAla.add(edellinen, 0, 0); 
        layoutAla.add(seuraava, 1, 0); 
        //
        //toiminnallisuus avaa seuraavan scenen
        edellinen.setOnMouseClicked(e -> {
        	
      		  Node node = (Node) e.getSource();
      		  Stage stage = (Stage) node.getScene().getWindow();
      		  
      		  try {
      			FXMLLoader loader = new FXMLLoader(getClass().getResource("LaivojenMaara.fxml"));
      			Parent root = loader.load();
      		   
      		    LaivojenMaaraController controller = loader.getController();
      		    controller.setData(u);
      		    loader.setController(controller);
      		
      		    Scene scene = new Scene(root);
      		    stage.setScene(scene);
      		    stage.show();
      		  }catch(Exception e1) {
      			  e1.printStackTrace();
      		  }
        });

	}

	public Scene getScene() {
		return sceneX;
		
	}

}
